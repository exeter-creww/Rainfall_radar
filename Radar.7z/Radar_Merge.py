# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 14:57:42 2019

@author: ph339
"""

import pandas as pd
import glob
from simpledbf import Dbf5
import datetime
import time


#Create a list of dates to loop through(from a .xlsx file)
dates = pd.read_excel('Z:/Data/1_Extracted_data/Met_Office/Radar/DateList.xlsx',header=None)
dates = dates[0].tolist()
print("Obtained dates")

#for each month(i) in the list dates loop through the following:
for i in dates:

    #Create a template dataframe from Strart_table.dbf
    data = Dbf5('Z:/Data/1_Extracted_data/Met_Office/Radar/Final_table/Start_Table.dbf') 
    data = data.to_dataframe()
    data.drop(data.index[0:3], inplace=True)
    print("stripped Start table for: ", i)

    #Create a list of files (f) to append together for each month from dates(i)
    for f in glob.glob('Z:/Data/1_Extracted_data/Met_Office/Radar/Tables_college/College%s*.dbf'%i):
        #Open relevant .dbf file
        dbf = Dbf5(f)
        #Convert .dbf to dataframe
        dbf = dbf.to_dataframe()
        print("dataframe conversion complete for: ", f)
        name = f.split("College")[1]
        date = name[0:8] 
        print(date)
        dbf["Date"] = date
        time = name[8:12]
        print(time)
        dbf["Time"] = time
        print(dbf)
        #append to dataframe
        data = data.append(dbf)
        #Save dataframe as .csv
    data.to_csv('Z:/Data/1_Extracted_data/Met_Office/Radar/Merged_Data/College%s.csv'%i)
    